globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/cbd55ab9639e1e66.js",
    "static/chunks/bba035711c7e37a2.js",
    "static/chunks/023d923a37d494fc.js",
    "static/chunks/c903f9580a4b6572.js",
    "static/chunks/turbopack-1ad58da399056f41.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];