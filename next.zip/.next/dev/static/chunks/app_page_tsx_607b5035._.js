(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_e2e8a72a._.js",
  "static/chunks/node_modules_next_3967d847._.js",
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_38c80ce2._.js",
  "static/chunks/node_modules_swiper_8e32b483._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_0459ff00._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/node_modules_e9588c09._.js",
  "static/chunks/_9697a494._.css"
],
    source: "dynamic"
});
